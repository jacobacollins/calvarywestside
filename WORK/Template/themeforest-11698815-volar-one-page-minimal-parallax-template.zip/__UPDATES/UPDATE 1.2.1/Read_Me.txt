\ \    / /  / __ \  | |          /\     |  __ \             /_ |     |__ \      /_ |
 \ \  / /  | |  | | | |         /  \    | |__) |    __   __  | |        ) |      | |
  \ \/ /   | |  | | | |        / /\ \   |  _  /     \ \ / /  | |       / /       | | 
   \  /    | |__| | | |____   / ____ \  | | \ \      \ V /   | |  _   / /_   _   | | 
    \/      \____/  |______| /_/    \_\ |_|  \_\      \_/    | | (_) |____| (_)  | |
                                                                           
===========================================================================

Volar | One Page Minimal Parallax Template,     Update 1.2.1,      2015-07-29

===========================================================================

** IMPORTANT: If You just bought this template nothing is here for you.
open the documentation and follow the instructions. **

===========================================================================
* By making some of these changes we had to update the css/styles.css and 
  css/styles.min.css, so if you have not changed the css files then just
  replace these new ones with the old ones.
  but if you have already made changes to the styles then we've prepared an
  addition css file which you can find in this folder with the name of:
  CSS_update1.2.1. Please read on.

* If you have used the update1.2 something went wrong about it. and we deeply
  apoligize for that.
  in that update we have made some changes in the styles.css file in order to
  solve a rare issue regarding portfolio filter buttons in Firefox, turns out
  it makessome other issues.
  the codes at the end of CSS_update1.2.css line: 165 are not useful, if you
  added them to the end of your styles please remove them.
  And if you came across an issue like unwanted gap between filter buttons in
  Firefox THEN add the styles in CSS_update1.2.1.css to the end of your styles.
  

* Due to a slight misplacing in Javascript file there was an issue in masonry
  portfolio section. so /js/scripts.js and /js/scripts.min.js have been changeed,
  just replace them with the new ones.


===========================================================================

Thank you so much for reading this. Ershad Qaderi, 2015-07-29
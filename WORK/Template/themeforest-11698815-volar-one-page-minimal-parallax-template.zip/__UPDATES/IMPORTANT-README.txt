
If You just bought this template nothing is here for you.
open the documentation and follow the instructions.
 __      __   ____    _                   _____                  __       ____        __  
 \ \    / /  / __ \  | |          /\     |  __ \                /_ |     |___ \      /_ |  
  \ \  / /  | |  | | | |         /  \    | |__) |       __   __  | |       __) |      | |
   \ \/ /   | |  | | | |        / /\ \   |  _  /        \ \ / /  | |      |__ <       | |
    \  /    | |__| | | |____   / ____ \  | | \ \         \ V /   | |  _   ___) |  _   | |
     \/      \____/  |______| /_/    \_\ |_|  \_\         \_/    |_| (_) |____/  (_)  |_|
                                                                                

===========================================================================

Volar | One Page Minimal Parallax Template,     Update 1.3.1,      2015-08-24

===========================================================================

**   IMPORTANT:   If You just bought this template nothing is here for you.
                  open the documentation and follow the instructions.

                  THIS UPDATE IS ADDITION TO UPDATE 1.3 YOU STILL NEED TO USE
		  THAT UPDATE ASWELL.

===========================================================================
* Apearantly there has been a problem with new home page version - masked text
  rotator in FireFox. so the codes related to index18.html and its styles have
  been updated. we've changed /css/styles.css, /css/styles.min.css and /js/animated
  -headlines.js, you can use the new ones in the main files or we've prepared some
  additional files that you can use.
  

* Check out the change-log in the item page at themeforest.net to see the changes.


===========================================================================

Thank you so much for reading this. Ershad Qaderi, 2015-08-24
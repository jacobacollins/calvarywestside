 __      __   ____    _                   _____                  __       ____        __  
 \ \    / /  / __ \  | |          /\     |  __ \                /_ |     |___ \      |__ \   
  \ \  / /  | |  | | | |         /  \    | |__) |       __   __  | |       __) |        ) |
   \ \/ /   | |  | | | |        / /\ \   |  _  /        \ \ / /  | |      |__ <        / / 
    \  /    | |__| | | |____   / ____ \  | | \ \         \ V /   | |  _   ___) |  _   / /_  
     \/      \____/  |______| /_/    \_\ |_|  \_\         \_/    |_| (_) |____/  (_) |____|
                                                                                

===========================================================================

Volar | One Page Minimal Parallax Template,     Update 1.3.2,      2015-09-04

===========================================================================

**   IMPORTANT:   If You just bought this template nothing is here for you.
                  open the documentation and follow the instructions.

===========================================================================
* We have Updated the index18.html in order to make it more customizable, before
  adding a new element under or above of the text rotator in index18.html was really
  tricky but now you can cange anything there as you do in other demo pages.
  
* We did not provide any add-on css file this, because it would make the code very 
  messy, instead just change the /css/styles.css and /css/styles.min.css with the
  new ones.

* if you decide to update your /css/styles.css file then you shoud update the home-section
  part in index18.html with the new one - note: you have to change JUST home-section codes.

* /css/animated-hedlines.css has been updated - due to a slight issue on Safari browsers.

* /js/scripts.js and /js/scripts.min.js have been updated.

===========================================================================

Thank you so much for reading this. Ershad Qaderi, 2015-08-24
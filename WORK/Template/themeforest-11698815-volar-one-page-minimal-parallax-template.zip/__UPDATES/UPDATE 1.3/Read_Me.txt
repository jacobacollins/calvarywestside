 __      __   ____    _                   _____                  __       ____  
 \ \    / /  / __ \  | |          /\     |  __ \                /_ |     |___ \ 
  \ \  / /  | |  | | | |         /  \    | |__) |       __   __  | |       __) |
   \ \/ /   | |  | | | |        / /\ \   |  _  /        \ \ / /  | |      |__ < 
    \  /    | |__| | | |____   / ____ \  | | \ \         \ V /   | |  _   ___) |
     \/      \____/  |______| /_/    \_\ |_|  \_\         \_/    |_| (_) |____/ 
                                                                                

===========================================================================

Volar | One Page Minimal Parallax Template,     Update 1.3,      2015-08-20

===========================================================================

**   IMPORTANT:   If You just bought this template nothing is here for you.
                  open the documentation and follow the instructions.

===========================================================================
* This update required some changes in the /css/styles.css and /css/styles.min.css,
  as well as /js/scripts.js and /js/scripts.min.js if you have not changed the
  styles.css ile then just copy the /css floder along with /js folder and paste
  them in your root folder. only the updated files are included. but if you have
  already made changes to the styles.css and do not want to overwrite it with this
  updated /css/styles.css file then we've prepaerd an addition css file which you
  can find in the root folder here under the name of: CSS_update1.3.css

* There is no addition JavaScript file so you have to use the updated version.
  

* Check out the change-log in the item page at themeforest.net to see the changes.


===========================================================================

Thank you so much for reading this. Ershad Qaderi, 2015-08-20
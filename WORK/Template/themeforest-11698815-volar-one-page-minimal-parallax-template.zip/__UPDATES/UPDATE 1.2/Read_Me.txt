\ \    / /  / __ \  | |          /\     |  __ \             /_ |     |__ \ 
 \ \  / /  | |  | | | |         /  \    | |__) |    __   __  | |        ) |
  \ \/ /   | |  | | | |        / /\ \   |  _  /     \ \ / /  | |       / / 
   \  /    | |__| | | |____   / ____ \  | | \ \      \ V /   | |  _   / /_ 
    \/      \____/  |______| /_/    \_\ |_|  \_\      \_/    |_| (_) |____|
                                                                           
===========================================================================

Volar | One Page Minimal Parallax Template,     Update 1.2,      2015-07-27

===========================================================================

** IMPORTANT: If You just bought this template nothing is here for you.
open the documentation and follow the instructions. **

===========================================================================
* By making some of these changes we had to update the css/styles.css and 
  css/styles.min.css, so if you have not changed the css files then just
  replace these new ones with the old ones, but if you have already made
  changes to the styles then we've prepared an addition css file which you
  can find in this folder with the name of: CSS_update1.2. open this file 
  copy its content and paste it at the end of your own styles. 

* We have added a new demo page which is a slideshow with static text on it.
  you can find this demo in main files with this name: ( index17.html ).

* We have added support for large logos in the navigation menu. in order to
  use your own logo you need to go to: /css/styles.css line: 1543 and set
  the line-height, if you are using CSS_update1.2 then it is in line:24. it must be same as the height of your logo. so if your
  logo dimansions are say: 200px*100px; the line-height has to be 100px,
  line-height: 100px.

* We solved some issues of porfolio buttons on Firefox.

* We have added to new color schemes; brown.css and pink.css. you can locate
  them here: /css/theme/ they are ready to use.





===========================================================================

Thank you so much for reading this. Ershad Qaderi, 2015-07-27
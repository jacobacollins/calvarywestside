Read about licensing details here: 

http://wiki.envato.com/support/legal-terms/licensing-terms/